<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservar Mesa</title>
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/png" />
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body>
    <header>
        <nav>
            <a href="<?php echo e(route('home')); ?>">Inicio</a>
            <a href="<?php echo e(route('reservations.index')); ?>">Reservas</a>
        </nav>
    </header>

    <main>
        <div>
            <h1>Reservar Mesa</h1>

            <div style="text-align: center; margin-bottom: 20px;">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-back">← Volver al Panel de Administración</a>
            </div>

    
            <form method="GET" action="<?php echo e(route('reservations.create')); ?>">
                <label for="space">Selecciona el Espacio:</label>
                <select name="space" id="space" onchange="this.form.submit()">
                    <?php $__currentLoopData = $spaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $space): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($space->name); ?>" <?php echo e($selectedSpace == $space->name ? 'selected' : ''); ?>>
                            <?php echo e($space->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>

            <?php if($tables->count() > 0): ?>
                <form method="POST" action="<?php echo e(route('reservations.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="grid-container">
                        <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid-item">
                                <label>
                                    <input type="radio" name="table_id" value="<?php echo e($table->id); ?>" required>
                                    <img src="<?php echo e(asset('images/' . $table->capacity . '.png')); ?>" alt="Mesa">
                                    <p>Mesa <?php echo e($table->id); ?></p>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="form-container">
                        <label for="customer_name">Nombre del Cliente:</label>
                        <input type="text" id="customer_name" name="customer_name" required>

                        <label for="customer_phone">Teléfono del Cliente:</label>
                        <input type="text" id="customer_phone" name="customer_phone" required>

                        <label for="num_people">Número de Personas:</label>
                        <input type="number" id="num_people" name="num_people" required min="1">

                        <label for="reservation_time">Fecha y Hora de la Reserva:</label>
                        <input type="datetime-local" id="reservation_time" name="reservation_time" required>

                        <button type="submit">Reservar</button>
                    </div>
                </form>
            <?php else: ?>
                <p>No hay mesas disponibles en este espacio.</p>
            <?php endif; ?>
        </div>

        <div class="reservations-container">
            <h2>Reservas del Día</h2>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="reservation-item">
                    <h3><?php echo e($reservation->customer_name); ?></h3>
                    <p>Hora: <?php echo e($reservation->reservation_time); ?></p>
                    <p>Personas: <?php echo e($reservation->num_people); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Gesto-rest. Todos los derechos reservados.</p>
    </footer>
</body>

</html>
<?php /**PATH C:\Users\melru\Documents\GitHub\gestor-reservas-restaurante\gesto-rest\resources\views/reservations/create.blade.php ENDPATH**/ ?>