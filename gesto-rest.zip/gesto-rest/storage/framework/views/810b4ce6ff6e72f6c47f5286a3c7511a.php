<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Empleado</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
</head>


<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(auth()->user()->role === 'admin' ? route('admin.dashboard') : route('reservations.create')); ?>">
                    <img src="<?php echo e(asset('images/looblanco2.png')); ?>" alt="Logo" height="40"> <small>Gesto-Rest</small>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('reservations.index')); ?>">Reservas</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <h1 class="text-center">Editar Empleado</h1>


    <main class="container mt-4">
      

        <form method="POST" action="<?php echo e(route('admin.users.update', $employee->id)); ?>" class="form-limited">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nombre</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e($employee->name); ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e($employee->email); ?>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Nueva Contraseña (opcional)</label>
                <input type="password" id="password" name="password" class="form-control">
            </div>

            <div class="mb-3">
                <label for="role" class="form-label">Rol</label>
                <select id="role" name="role" class="form-select" required>
                    <option value="admin" <?php echo e($employee->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="employee" <?php echo e($employee->role === 'employee' ? 'selected' : ''); ?>>Empleado</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary w-100">Actualizar</button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary w-100 mt-2">Cancelar</a>
        </form>
        
    </main>
    <a onclick="window.history.back()" >Volver atrás</a>

    <footer class="text-center mt-4 bg-dark text-white py-3">
        <p>&copy; 2024 Gesto-rest. Todos los derechos reservados.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\melru\Documents\GitHub\gestor-reservas-restaurante\gesto-rest\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>