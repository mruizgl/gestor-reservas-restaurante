<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Mesas</title>
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(auth()->user()->role === 'admin' ? route('admin.dashboard') : route('reservations.create')); ?>">
                    <img src="<?php echo e(asset('images/looblanco2.png')); ?>" alt="Logo" height="40"> <small> Gesto-Rest
                        
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('reservations.index')); ?>">Reservas</a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <br>
    <br>

    <div style="text-align: center; margin-bottom: 20px;">
        <a href="<?php echo e(route('admin.dashboard')); ?>" >← Volver al Panel de Administración</a>
    </div>

    <main>
        <div class="container">
            <h1>Añadir Mesas al Espacio</h1>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php elseif(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form method="GET" action="<?php echo e(route('tables.create')); ?>" style="text-align: center; margin-bottom: 20px;">
                <label for="space">Selecciona el Espacio:</label>
                <select name="space_id" id="space">
                    <?php $__currentLoopData = $spaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $space): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($space->id); ?>" <?php echo e(request('space_id') == $space->id ? 'selected' : ''); ?>>
                            <?php echo e($space->name); ?> (<?php echo e($space->rows); ?>x<?php echo e($space->columns); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn-select">Seleccionar</button>
            </form>

            <?php if($selectedSpace): ?>
                <form method="POST" action="<?php echo e(route('tables.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="space_id" value="<?php echo e($selectedSpace->id); ?>">

                    <div class="grid-container" style="grid-template-columns: repeat(<?php echo e($selectedSpace->columns); ?>, 1fr);">
                        <?php for($row = 1; $row <= $selectedSpace->rows; $row++): ?>
                            <?php for($col = 1; $col <= $selectedSpace->columns; $col++): ?>
                                <div class="grid-item">
                                    <label for="table_<?php echo e($row); ?>_<?php echo e($col); ?>">
                                        Mesa <?php echo e($row); ?>-<?php echo e($col); ?>

                                    </label>
                                    <input type="checkbox" id="table_<?php echo e($row); ?>_<?php echo e($col); ?>" name="tables[]" value="<?php echo e($row); ?>-<?php echo e($col); ?>">
                                    <select name="capacity[<?php echo e($row); ?>-<?php echo e($col); ?>]" disabled>
                                        <option value="" disabled selected>Capacidad</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="6">6</option>
                                        <option value="10">10</option>
                                    </select>
                                </div>
                            <?php endfor; ?>
                        <?php endfor; ?>
                    </div>

                    <button type="submit" class="btn btn-primary">Guardar Mesas</button>
                </form>
            <?php else: ?>
                <p>Por favor, selecciona un espacio para añadir mesas.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Gesto-rest. Todos los derechos reservados.</p>
    </footer>

    <style>
        .grid-container {
            display: grid;
            gap: 10px;
            background-color: #f7f7f7;
            padding: 10px;
            border-radius: 10px;
        }

        .grid-item {
            background-color: #e8e8e8;
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
        }

        select {
            width: 100%;
            margin-top: 5px;
        }

        .btn-back {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2488C1;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .btn-back:hover {
            background-color: #B64C78;
        }

        .btn-select {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2488C1;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            margin-left: 10px;
            transition: background-color 0.3s ease;
        }

        .btn-select:hover {
            background-color: #B64C78;
        }
    </style>

    <script>
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const select = this.closest('.grid-item').querySelector('select');
                select.disabled = !this.checked;
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\melru\Documents\GitHub\gestor-reservas-restaurante\gesto-rest\resources\views/admin/tables/create.blade.php ENDPATH**/ ?>